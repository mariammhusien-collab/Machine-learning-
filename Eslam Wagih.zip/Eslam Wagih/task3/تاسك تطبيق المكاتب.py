#%%   NUMPY + PANDAS




import numpy as np
import pandas as pd


# درجات 5 طلاب
data_matrix = np.array([
    [85, 90, 78],
    [60, 70, 65],
    [92, 95, 98],
    [75, 80, 70],
    [50, 55, 60]
])


student_names = [
    'Alice',
    'Bob',
    'Charlie',
    'David',
    'Eva'
]


subjects = [
    'Math',
    'Statistics',
    'Python'
]



df = pd.DataFrame(
    data=data_matrix,
    index=student_names,
    columns=subjects
)

print(df)



print("\nCharlie's Grades:")

print(df.loc['Charlie'])


print("\nBob Statistics Grade:")

print(df.iloc[1, 1])



print("\nMean of each subject:")

print(df.mean(axis=0))


df['Total'] = df.sum(axis=1)

print("\nFinal DataFrame:")

print(df)

#%%   MATPLOTLIB


import numpy as np
import matplotlib.pyplot as plt


x = np.array([1, 2, 3, 4, 5])

y = np.array([10, 20, 30, 40, 50])


plt.plot(x, y)

plt.title("Simple Line Plot")

plt.xlabel("X Values")

plt.ylabel("Y Values")

plt.grid(True)

plt.show()


area = np.array([
    1000, 1500, 1800, 2400, 3000
])

price = np.array([
    150, 220, 260, 340, 420
])


plt.scatter(area, price)

plt.title("House Price vs Area")

plt.xlabel("Area")

plt.ylabel("Price")

plt.grid(True)

plt.show()


names = [
    'Ahmed', 'Mona', 'Ali', 'Sara'
]

scores = [
    80, 90, 70, 85
]


plt.bar(names, scores)

plt.title("Students Scores")

plt.xlabel("Students")

plt.ylabel("Score")

plt.show()


ages = [
    20, 22, 25, 25, 27,
    30, 32, 35, 35, 40
]


plt.hist(ages, bins=5)

plt.title("Age Distribution")

plt.xlabel("Age")

plt.ylabel("Frequency")

plt.show()



x = np.array([1, 2, 3, 4, 5])

y1 = np.array([10, 20, 30, 40, 50])

y2 = np.array([5, 15, 25, 35, 45])


plt.plot(x, y1, label="Data 1")

plt.plot(x, y2, label="Data 2")

plt.title("Comparison")

plt.xlabel("X")

plt.ylabel("Value")

plt.legend()

plt.grid(True)

plt.show()





#%%  SEABORN


import numpy as np

from sklearn.linear_model import LinearRegression


# X = Hours of Study
X = np.array([
    [1],
    [2],
    [3],
    [4],
    [5]
])


y = np.array([
    50,
    55,
    65,
    70,
    80
])



model = LinearRegression()



model.fit(X, y)



prediction = model.predict(
    [[6]]
)


print("Predicted Score:")

print(prediction)


#%%  PYTORCH


import torch

import torch.nn as nn

import torch.optim as optim


# Relationship: y = 2x

X_tensor = torch.tensor(
    [
        [1.0],
        [2.0],
        [3.0],
        [4.0]
    ],
    dtype=torch.float32
)


y_tensor = torch.tensor(
    [
        [2.0],
        [4.0],
        [6.0],
        [8.0]
    ],
    dtype=torch.float32
)


class SimpleNN(nn.Module):

    def init(self):

        super(SimpleNN, self).init()

        self.linear = nn.Linear(
            in_features=1,
            out_features=1
        )


    def forward(self, x):

        return self.linear(x)




model = SimpleNN()


criterion = nn.MSELoss()


optimizer = optim.SGD(
    model.parameters(),
    lr=0.01
)



for epoch in range(1000):

    # Forward Pass

    y_pred = model(X_tensor)



    loss = criterion(
        y_pred,
        y_tensor
    )



    optimizer.zero_grad()


    loss.backward()


    optimizer.step()



    if (epoch + 1) % 100 == 0:

        print(
            f"Epoch {epoch + 1}, "
            f"Loss = {loss.item():.4f}"
        )


test_val = torch.tensor(
    [[5.0]],
    dtype=torch.float32
)


predicted = model(test_val)


print("\nPrediction for x = 5:")

print(predicted.item())





