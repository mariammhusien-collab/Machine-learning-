#%% السؤال 1- Matrix Dimensions & Indexing

import numpy as np
 
M = np.array([
    [4, -2, 7, 0],
    [1, 9, 3, -5],
    [8, 6, -1, 2]])
 
# Dimensions
print("Dimensions:", M.shape)
 
# Elements
print("m1,3 =", M[0, 2])
print("m2,4 =", M[1, 3])
print("m3,2 =", M[2, 1])


#%% السؤال 2 - Matrix Addition & Subtraction

A = np.array([
    [3, 5],
    [-1, 4]])

B = np.array([
    [0, -2],
    [7, 1]])

C = np.array([
    [1, 2, 3],
    [4, 5, 6]])

print("A + B:")
print(A + B)

print("A - B:")
print(A - B)

print("A dimensions:", A.shape)
print("C dimensions:", C.shape)





#%% السؤال 3 - Scalar & Matrix Multiplication

X = np.array([
    [2, -1],
    [3, 0]
])

Y = np.array([
    [1, 4],
    [-2, 5]
])

print("3X:")
print(3 * X)

print("Element-wise multiplication:")
print(X * Y)

print("Matrix multiplication:")
print(X @ Y)




#%% السؤال 4 - Transpose, Determinant & Inverse

import numpy as np
k =np.array([[5,2],[3,4]])

print(k.T)
print(np.linalg.det(k))
print(np.linalg.inv(k))


#%% السؤال 5 - System of Linear Equations

import numpy as np
 
A = np.array([
    [2, 3],
    [4, -1]])
 
B = np.array([13, 5])
 
X = np.linalg.solve(A, B)
 
print("x =", X[0])
print("y =", X[1])


#%% السؤال 6 - Mean, Median & Mode



import numpy as np
from statistics import mode
data =np.array([
    120,150,130,180,
    150,200,110,160
    ])

mean = np.mean(data)
median = np.median(data)
mode = np.mode(data)

print("mean=", mean)
print("median=", median)
print("mode=", mode)



#%% السؤال 7 - Standard Deviation & IQR


import numpy as np
 
data = np.array([2, 4, 6, 8, 10])
 
# ddof=1 gives the sample standard deviation
sample_std = np.std(data, ddof=1)
 
Q1 = np.percentile(data, 25, method="midpoint")
Q3 = np.percentile(data, 75, method="midpoint")
IQR = Q3 - Q1
 
print("Sample standard deviation=", sample_std)
print("Q1=", Q1)
print("Q3=", Q3)
print("IQR=", IQR)


#%% السؤال 8 - Missing Values & Min-Max Scaling


area = [1200, None, 1800]
 
# Step 1: Calculate the mean of the known values
known_values = [1200, 1800]
mean_value = sum(known_values) / len(known_values)
print("Mean value:", mean_value)
 
# Step 2: Replace the missing value with the mean
area[1] = mean_value
print("Area after filling missing value:", area)
 
# Step 3: Apply Min-Max scaling manually
x_min = min(area)
x_max = max(area)
 
scaled_area = []
for x in area:
    scaled_value = (x - x_min) / (x_max - x_min)
    scaled_area.append(scaled_value)
 
print("Scaled Area:", scaled_area)



#%% السؤال 9 - Train / Test Split

import numpy as np

from sklearn.model_selection import train_test_split

X = np.arange(100)
X_train, X_test = train_test_split(
    X,
    test_size=0.2,
    random_state=42
)

print( len(X_train))
print( len(X_test))



#%% السؤال 10 - Linear Regression Prediction & Residual

import numpy as np

age = 4

predicted_price = -2000 * age + 25000

actual_price = 16000

residual = actual_price - predicted_price

print("Predicted Price =", predicted_price)
print("Residual =", residual)

